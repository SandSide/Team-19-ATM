﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace ATM
{
    public partial class startForm : Form
    {


        //ATMPROGRAM temp = new ATMPROGRAM(); 
        public startForm()
        {

            InitializeComponent();
            ATMPROGRAM n = new ATMPROGRAM(this);

        }
    
    /*
    *   This is the root of program and the entry point
    * 
    *   Class programm contains an array of account objects and a singel ATM object  
    * 
    */
    class ATMPROGRAM
    {
        private Account[] ac = new Account[3];
        private ATM atm;
        private ATM atm2;

        /*
         * This function initilises the 3 accounts 
         * and instanciates the ATM class passing a referance to the account information
         * 
         */
        public ATMPROGRAM(Form test)
        {

            ac[0] = new Account(300, 1111, 111111);
            ac[1] = new Account(750, 2222, 222222);
            ac[2] = new Account(3000, 3333, 333333);

            Thread ATM2 = new Thread(new ThreadStart(ThreadProc));
            ATM2.Start();
        }

        public void ThreadProc()
        {
            var frm = new ATM(ac);
           // frm.ShowDialog();

        }
    }
    /*
     *   The Account class encapusulates all features of a simple bank account
     */
    class Account
    {
        //the attributes for the account
        private int balance;
        private int pin;
        private int accountNum;

        // a constructor that takes initial values for each of the attributes (balance, pin, accountNumber)
        public Account(int balance, int pin, int accountNum)
        {
            this.balance = balance;
            this.pin = pin;
            this.accountNum = accountNum;
        }

        //getter and setter functions for balance
        public int getBalance()
        {

            return balance;

        }
        public void setBalance(int newBalance)
        {

            this.balance = newBalance;

        }

        /*
         *   This funciton allows us to decrement the balance of an account
         *   it perfomes a simple check to ensure the balance is greater tha
         *   the amount being debeted
         *   
         *   reurns:
         *   true if the transactions if possible
         *   false if there are insufficent funds in the account
         */
        public Boolean decrementBalance(int amount)
        {
            if (this.balance > amount)
            {

                balance -= amount;
                return true;

            }
            else
            {

                return false;

            }
        }

        /*
         * This funciton check the account pin against the argument passed to it
         *
         * returns:
         * true if they match
         * false if they do not
         */
        public Boolean checkPin(int pinEntered)
        {

            if (pinEntered == pin)
            {

                return true;

            }
            else
            {

                return false;

            }
        }


        public int getAccountNum()
        {

            return accountNum;
        }

    }

    /* 
     *      This is out main ATM class that preforms the actions outlined in the assigment hand out
     *      
     *      the constutor contains the main funcitonality.
     */
    class ATM
    {

        //local referance to the array of accounts
        private Account[] ac;

        //this is a referance to the account that is being used
        private Account activeAccount = null;

        private Form n;
        private RichTextBox mainScreen;
        private TextBox inputBox;

        private Button enterAccountButton;
        private Button enterPinButton;

        private Button withdrawButton;
        private Button balanceButton;
        private Button exitButton;

        //private Button enterPin;

        private String input = null;

        // the atm constructor takes an array of account objects as a referance
        public ATM(Account[] ac)
        {
            this.ac = ac;
            createForm();
            start();

         }

        /*
         * Creates form for ATM
         * 
         */
        public void createForm()
        {

            n = new Form();
            n.Size = new Size(400, 600);

            mainScreen = new RichTextBox();
            mainScreen.SetBounds(50, 100, 200, 100);

            inputBox = new TextBox();
            inputBox.SetBounds(50, 300, 300, 50);

            enterAccountButton = new Button();
            enterAccountButton.Click += new EventHandler(this.enterAccount);
            enterAccountButton.SetBounds(100, 250, 200, 50);
            enterAccountButton.Text = "Find Account";

            enterPinButton = new Button();
            enterPinButton.Click += new EventHandler(this.checkPin);
            enterPinButton.SetBounds(100, 250, 200, 50);
            enterPinButton.Text = "Find Pin";
            enterPinButton.Visible = false;

            withdrawButton = new Button();
            withdrawButton.Click += new EventHandler(this.withdrawCash);
            withdrawButton.SetBounds(50, 320, 100, 50);
            withdrawButton.Text = "Withdraw";
            withdrawButton.Visible = false;


            balanceButton = new Button();
            balanceButton.Click += new EventHandler(this.displayBalance);
            balanceButton.SetBounds(50, 370, 100, 50);
            balanceButton.Text = "Display Balance";
            balanceButton.Visible = false;

            exitButton = new Button();
            exitButton.Click += new EventHandler(this.exitAccount);
            exitButton.SetBounds(50, 420, 100, 50);
            exitButton.Text = "Exit";
            exitButton.Visible = false;

            /*
                enterAccountButton.Visible = false;
                enterPinButton.Visible = false;
                withdrawButton.Visible = false;
                balanceButton.Visible = false;
                exitButton.Visible = false;
            */

            n.Controls.Add(mainScreen);
            n.Controls.Add(inputBox);
            n.Controls.Add(enterAccountButton);
            n.Controls.Add(enterPinButton);
            n.Controls.Add(withdrawButton);
            n.Controls.Add(balanceButton);
            n.Controls.Add(exitButton);
            n.Show();

        }

        /*
         * Starts the ATM, screen asks for account number
         * 
         */
        public void start()
        {

            mainScreen.Text = "Enter Account Number";

        }

        /*
         * When button clicked, uses input in inputbox as customer number to search for.
         * 
         */
        private void enterAccount(object sender, EventArgs e)
        {

            // Gets inputs in input box
            input = inputBox.Text;

            // Searches for account "input"
            findAccount(Int32.Parse(input));

        }

        /*
         * Searches for account number
         * 
         */
        private void findAccount(int account)
        {   
         
            bool found = false;


            for (int i = 0; i < this.ac.Length; i++)
            {

                // if accountNum is in accounts
                if (ac[i].getAccountNum() == account)
                {

                    // set it as currently active account
                    activeAccount =  ac[i];
                    found = true;
                    mainScreen.Text = "Account Found\n";
                    enterAccountButton.Visible = false;
                        

                    // Asks for pin input
                    mainScreen.Text += "Please Enter Pin.";
                    enterPinButton.Visible = true;

                }
                
            }

            // If not found
            if(found == false)
            {
                activeAccount = null;
                mainScreen.Text = "Account Not Found";

            }

            inputBox.Text = "";

        }


        /*
         * Checks if text in inputbox matches currently activeaccounts pin
         * 
         */
        private void checkPin(object sender, EventArgs e)
        {

            //  Check if pin is correct
            if (activeAccount.checkPin(Int32.Parse(inputBox.Text)))
            {
                mainScreen.Text = "\nCorrect Pin Entered.";
                //if the pin is a match give the options to do stuff to the account (take money out, view balance, exit)
                dispOptions();
            }
            else
            {
                mainScreen.Text = "In-Correct Pin Entered.";
                mainScreen.Text += "\nPlease Enter Account Number:";
                enterAccountButton.Visible = true;
                enterPinButton.Visible = false;

            }
        }

        /*
         *  Display account options
         *  
         */
        private void dispOptions()
        {

            mainScreen.Text += "\n1: take out cash\n";
            mainScreen.Text += "2: balance\n";
            mainScreen.Text += "3: exit\n";

            enterPinButton.Visible = false;
            withdrawButton.Visible = true;
            balanceButton.Visible = true;
            exitButton.Visible = true;


        }

        /*
         * Creates withdraw buttons
         *
         */
        private void withdrawCash(object sender, EventArgs e)
        {

            Button withdraw10 = new Button();
            withdraw10.Click += new EventHandler(this.withdraw10);
            withdraw10.SetBounds(50, 250, 100, 50);
            withdraw10.Text = "Withdraw 10";


            Button withdraw50 = new Button();
            withdraw50.Click += new EventHandler(this.withdraw50);
            withdraw50.SetBounds(50, 310, 100, 50);
            withdraw50.Text = "Withdraw 50";
            Button withdraw500 = new Button();

            withdraw500 = new Button();
            withdraw500.Click += new EventHandler(this.withdraw500);
            withdraw500.SetBounds(50, 370, 100, 50);
            withdraw500.Text = "Withdraw 500";

            mainScreen.Text = "Withdraw";

            withdrawButton.Visible = false;
            balanceButton.Visible = false;
            exitButton.Visible = false;

            n.Controls.Add(withdraw10);
            n.Controls.Add(withdraw50);
            n.Controls.Add(withdraw500);

        }


        // Withdraw 10 money
        private void withdraw10(object sender, EventArgs e)
        {


            //attempt to decrement account by 10 punds
            if (activeAccount.decrementBalance(10))
            {
                //if this is possible display new balance and await key press
                mainScreen.Text = "new balance " + activeAccount.getBalance();
 
            }
            else
            {
                mainScreen.Text = "insufficent funds";
            }

        }

        // Withdraw 50 money
        private void withdraw50(object sender, EventArgs e)
        {

            if (activeAccount.decrementBalance(50))
            {
                mainScreen.Text = "new balance " + activeAccount.getBalance();
            }
            else
            {
                mainScreen.Text = "insufficent funds";
            }

        }

        // Withdraw 500 money
        private void withdraw500(object sender, EventArgs e)
        {

            if (activeAccount.decrementBalance(500))
            {
                mainScreen.Text = "new balance " + activeAccount.getBalance();
            }
            else
            {
                mainScreen.Text = "insufficent funds";

            }

        }

        /*
        *  display balance of activeAccount
        *  
        */
        private void displayBalance(object sender, EventArgs e)
        {

            mainScreen.Text += " " + activeAccount.getBalance();

        }

        private void exitAccount(object sender, EventArgs e)
        {

            mainScreen.Text = "Please Enter Account Number";
            enterAccountButton.Visible = true;
            enterPinButton.Visible = false;
            withdrawButton.Visible = false;
            balanceButton.Visible = false;
            exitButton.Visible = false;

        }
    }
}
}