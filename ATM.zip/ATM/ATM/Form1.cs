﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace ATM
{
    public partial class startForm : Form
    {

        //ATMPROGRAM temp = new ATMPROGRAM(); 
        public startForm()
        {

            InitializeComponent();
            ATMPROGRAM n = new ATMPROGRAM(this);

        }

    }
    /*
    *   This is the root of program and the entry point
    * 
    *   Class programm contains an array of account objects and a singel ATM object  
    * 
    */
    class ATMPROGRAM
    {
        private Account[] ac = new Account[3];

        /*
         * This function initilises the 3 accounts 
         * and instanciates the ATM class passing a referance to the account information
         * 
         */
        public ATMPROGRAM(Form test)
        {

            ac[0] = new Account(300, 1111, 111111);
            ac[1] = new Account(750, 2222, 222222);
            ac[2] = new Account(3000, 3333, 333333);

            Thread ATM = new Thread(new ThreadStart(startATM));
            ATM.Start();

            Thread ATM2 = new Thread(new ThreadStart(startATM));
            ATM2.Start();

        }

        public void startATM()
        {
            
            ATM atm = new ATM(ac);

            while (atm.getExitStatus() ==  false)
            {

                Thread.Sleep(10000);


            }

        }

    }


    /*
     *   The Account class encapusulates all features of a simple bank account
     */
    class Account
    {
        //the attributes for the account
        private int balance;
        private int pin;
        private int accountNum;

        private readonly object balanceLock = new object();

        // a constructor that takes initial values for each of the attributes (balance, pin, accountNumber)
        public Account(int balance, int pin, int accountNum)
        {
            this.balance = balance;
            this.pin = pin;
            this.accountNum = accountNum;
        }

        //getter and setter functions for balance
        public int getBalance()
        {

            return balance;

        }
        public void setBalance(int newBalance)
        {

            this.balance = newBalance;

        }

        /*
         *   This funciton allows us to decrement the balance of an account
         *   it perfomes a simple check to ensure the balance is greater tha
         *   the amount being debeted
         *   
         *   reurns:
         *   true if the transactions if possible
         *   false if there are insufficent funds in the account
         */
        public Boolean decrementBalance(int amount)
        {

            lock (balanceLock)
            {

                if (this.balance >= amount)
                {

                    Random rnd = new Random();
                    int r = rnd.Next(1, 4);

                    /*
                    switch (r)
                    {
                        case 1:
                            Thread.Sleep(1000);
                            break;
                        case 2:
                            Thread.Sleep(5000);
                            break;
                        case 3:
                            Thread.Sleep(10000);
                            break;

                    }
                    */
                    balance -= amount;
                    return true;

                }
                else
                {

                    return false;

                }
            }
        }

        /*
         * This funciton check the account pin against the argument passed to it
         *
         * returns:
         * true if they match
         * false if they do not
         */
        public Boolean checkPin(int pinEntered)
        {

            if (pinEntered == pin)
            {

                return true;

            }
            else
            {

                return false;

            }
        }


        public int getAccountNum()
        {

            return accountNum;

        }

    }

    /* 
     *      This is out main ATM class that preforms the actions outlined in the assigment hand out
     *      
     *      the constutor contains the main funcitonality.
     */
    class ATM
    {
        //local referance to the array of accounts
        private Account[] ac;
        private bool exitStatus;

        private int accountNumber;

        //this is a referance to the account that is being used
        private Account activeAccount = null;

        private Form n;
        private RichTextBox mainScreen;
        private TextBox inputBox;

        private Button enterAccountButton;
        private Button enterPinButton;

        private Button withdrawButton;
        private Button balanceButton;
        private Button exitAccountButton;

        private Button withdraw10Button;
        private Button withdraw50Button;
        private Button withdraw500Button;


        // the atm constructor takes an array of account objects as a referance
        public ATM(Account[] ac)
        {
            this.ac = ac;
            createForm();
            exitStatus = false;

        }

        public bool getExitStatus()
        {

            return exitStatus;

        }

        /*
         * Creates form for ATM
         * 
         */
        public void createForm()
        {

            n = new Form();
            n.Size = new Size(400, 600);

            mainScreen = new RichTextBox();
            mainScreen.SetBounds(50, 100, 200, 100);
            mainScreen.Text += "Enter Account Number.";

            inputBox = new TextBox();
            inputBox.SetBounds(50, 300, 300, 50);

            enterAccountButton = new Button();
            enterAccountButton.Click += new EventHandler(this.enterAccount);
            enterAccountButton.SetBounds(100, 250, 200, 50);
            enterAccountButton.Text = "Find Account";
            enterAccountButton.Visible = true;

            enterPinButton = new Button();
            enterPinButton.Click += new EventHandler(this.enterPin);
            enterPinButton.SetBounds(100, 250, 200, 50);
            enterPinButton.Text = "Find Pin";
            enterPinButton.Visible = false;

            withdrawButton = new Button();
            withdrawButton.Click += new EventHandler(this.withdrawCash);
            withdrawButton.SetBounds(50, 320, 100, 50);
            withdrawButton.Text = "Withdraw";
            withdrawButton.Visible = false;

            withdraw10Button = new Button();
            withdraw10Button.Click += new EventHandler(this.withdraw10);
            withdraw10Button.SetBounds(50, 250, 100, 50);
            withdraw10Button.Text = "Withdraw 10";
            withdraw10Button.Visible = false;


            withdraw50Button = new Button();
            withdraw50Button.Click += new EventHandler(this.withdraw50);
            withdraw50Button.SetBounds(50, 310, 100, 50);
            withdraw50Button.Text = "Withdraw 50";
            withdraw50Button.Visible = false;

            withdraw500Button = new Button();
            withdraw500Button.Click += new EventHandler(this.withdraw500);
            withdraw500Button.SetBounds(50, 370, 100, 50);
            withdraw500Button.Text = "Withdraw 500";
            withdraw500Button.Visible = false;

            balanceButton = new Button();
            balanceButton.Click += new EventHandler(this.displayBalance);
            balanceButton.SetBounds(50, 370, 100, 50);
            balanceButton.Text = "Display Balance";
            balanceButton.Visible = false;

            exitAccountButton = new Button();
            exitAccountButton.Click += new EventHandler(this.exitAccount);
            exitAccountButton.SetBounds(50, 420, 100, 50);
            exitAccountButton.Text = "Exit";
            exitAccountButton.Visible = false;

            n.Controls.Add(mainScreen);
            n.Controls.Add(inputBox);
            n.Controls.Add(enterAccountButton);
            n.Controls.Add(enterPinButton);
            n.Controls.Add(withdrawButton);
            n.Controls.Add(balanceButton);
            n.Controls.Add(exitAccountButton);
            n.Controls.Add(withdraw10Button);
            n.Controls.Add(withdraw50Button);
            n.Controls.Add(withdraw500Button);
            n.ShowDialog();

        }


        /*
         * When button clicked, uses input in inputbox as customer number to search for.
         * 
         */
        private void enterAccount(object sender, EventArgs e)
        {

            // Gets inputs in input box
            accountNumber = Int32.Parse(inputBox.Text);
            enterAccountButton.Visible = false;
            inputBox.Text = "";

            // Asks for pin input
            mainScreen.Text = "Please Enter Pin.";
            enterPinButton.Visible = true;

        }

        /*
         * When button clicked, uses input in inputbox as customer number to search for.
         * 
         */
        private void enterPin(object sender, EventArgs e)
        {

            // Gets inputs in input box
            int pin = Int32.Parse(inputBox.Text);
            inputBox.Text = "";
            checkEnterDetails(pin);

        }

        public void checkEnterDetails(int pin)
        {

            if (this.findAccount(accountNumber) == true)
            {

                if (checkPin(pin) == true)
                {

                    mainScreen.Text = "Welcome " + activeAccount.getAccountNum();
                    dispOptions();

                }
                else
                {

                    mainScreen.Text = "Incorrect Pin";
                    mainScreen.Text += "Enter Account Number.";
                    enterAccountButton.Visible = true;
                    enterPinButton.Visible = false;

                }


            }
            else
            {

                mainScreen.Text = "Account Number does not match any existing Accounts.";
                mainScreen.Text += "Enter Account Number.";
                enterAccountButton.Visible = true;
                enterPinButton.Visible = false;

            }

        }

        /*
         * Searches for account number
         * 
         */
        private bool findAccount(int account)
        {   
         
            for (int i = 0; i < this.ac.Length; i++)
            {

                // if accountNum is in accounts
                if (ac[i].getAccountNum() == account)
                {

                    activeAccount = ac[i];
                    return true;

                }
                
            }

            return false;

        }


        /*
         * Checks if text in inputbox matches currently activeaccounts pin
         * 
         */
        private bool checkPin(int pin)
        {

            //  Check if pin is correct
            if (activeAccount.checkPin(pin))
            {
                //if the pin is a match give the options to do stuff to the account (take money out, view balance, exit)
                return true;

            }
            else
            {

                return false;

            }
        }

        /*
         *  Display account options
         *  
         */
        private void dispOptions()
        {

            mainScreen.Text += "\n1: Withdraw\n";
            mainScreen.Text += "2: View Balance\n";
            mainScreen.Text += "3: Exit Account\n";

            withdraw10Button.Visible = false;
            withdraw10Button.Visible = false;
            withdraw10Button.Visible = false;
            enterPinButton.Visible = false;
            withdrawButton.Visible = true;
            balanceButton.Visible = true;
            exitAccountButton.Visible = true;


        }

        /*
         * Creates withdraw buttons
         *
         */
        private void withdrawCash(object sender, EventArgs e)
        {


            mainScreen.Text = "Withdraw";

            withdraw10Button.Visible = true;
            withdraw50Button.Visible = true;
            withdraw500Button.Visible = true;

            withdrawButton.Visible = false;
            balanceButton.Visible = false;
            exitAccountButton.Visible = false;

        }


        // Withdraw 10 money
        private void withdraw10(object sender, EventArgs e)
        {


            //attempt to decrement account by 10 punds
            if (activeAccount.decrementBalance(10))
            {
                //if this is possible display new balance and await key press
                mainScreen.Text = "new balance " + activeAccount.getBalance();
 
            }
            else
            {
                mainScreen.Text = "insufficent funds";
                
            }

            dispOptions();

        }

        // Withdraw 50 money
        private void withdraw50(object sender, EventArgs e)
        {

            if (activeAccount.decrementBalance(50))
            {

                mainScreen.Text = "new balance " + activeAccount.getBalance();

            }
            else
            {
                mainScreen.Text = "insufficent funds";
               
            }

            dispOptions();

        }

        // Withdraw 500 money
        private void withdraw500(object sender, EventArgs e)
        {

            if (activeAccount.decrementBalance(500))
            {

                mainScreen.Text = "new balance " + activeAccount.getBalance();

            }
            else
            {

                mainScreen.Text = "Insufficent funds";


            }

            dispOptions();

        }

        /*
        *  display balance of activeAccount
        *  
        */
        private void displayBalance(object sender, EventArgs e)
        {

            mainScreen.Text = " " + activeAccount.getBalance();
            dispOptions();

        }

        private void exitAccount(object sender, EventArgs e)
        {

            mainScreen.Text = "Please Enter Account Number";
            enterAccountButton.Visible = true;
            enterPinButton.Visible = false;
            withdrawButton.Visible = false;
            balanceButton.Visible = false;
            exitAccountButton.Visible = false;
            withdraw10Button.Visible = false;
            withdraw50Button.Visible = false;
            withdraw500Button.Visible = false;

        }

        private void exitATM(object sender, EventArgs e)
        {

                exitStatus = true;

        }
    }

}