﻿using System;
using System.Drawing;
using System.Threading;
using System.Media;
using System.Windows.Forms;

namespace ATM
{
    public partial class startForm : Form
    {
        ATMPROGRAM bank;
        Bitmap button = new Bitmap(Properties.Resources.Button);
        //ATMPROGRAM temp = new ATMPROGRAM(); 

        public startForm()
        {

            InitializeComponent();
            bank = new ATMPROGRAM();

            Button newATM = new Button();

            //Models the new ATM button
            newATM.SetBounds(245, 420, 100, 50);
            newATM.Text = "Create ATM";
            newATM.Click += newATM_Click;
            newATM.Image = button;
            newATM.FlatStyle = FlatStyle.Flat;
            newATM.BackColor = Color.Transparent;
            newATM.FlatAppearance.BorderSize = 0;
            newATM.TabStop = false;
            newATM.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            newATM.BackgroundImageLayout = ImageLayout.Stretch;
            newATM.FlatAppearance.MouseDownBackColor = Color.Transparent;
            newATM.FlatAppearance.MouseOverBackColor = Color.Transparent;
            Controls.Add(newATM);


            this.Text = "BANK";

        }



        public void newATM_Click(object sender, EventArgs e)
        {
            bank.newATM();

        }

        private void startForm_Load(object sender, EventArgs e)
        {

        }

        
    }


    /*
    *   This is the root of program and the entry point
    * 
    *   Class programm contains an array of account objects.
    *   It Creates 2 Threads which each create an instance of an ATM
    * 
    */
    class ATMPROGRAM
    {
        private Account[] ac = new Account[3];

        /*
         * This function initilises the 3 accounts 
         * 
         */
        public ATMPROGRAM()
        {

            ac[0] = new Account(300, 1111, 111111);
            ac[1] = new Account(750, 2222, 222222);
            ac[2] = new Account(3000, 3333, 333333);

        }

        public void newATM()
        {
            //  Creates 2 Threads
            Thread ATM = new Thread(new ThreadStart(startATM));
            ATM.Start();

        }

        /*
         * Starts ATM
         *
         */
        public void startATM()
        {

            ATM atm = new ATM(ac);

        }

    }


    /*
     *   The Account class encapusulates all features of a simple bank account
     */
    class Account
    {
        //  The attributes for the account
        private int balance;
        private int pin;
        private int accountNum;
        private int amount;

        private readonly object balanceLock = new object();

        //  A constructor that takes initial values for each of the attributes (balance, pin, accountNumber)
        public Account(int balance, int pin, int accountNum)
        {
            this.balance = balance;
            this.pin = pin;
            this.accountNum = accountNum;
        }

        //  Getter and setter functions for balance
        public int getBalance()
        {

            return balance;

        }

        public void setBalance(int newBalance)
        {

            this.balance = newBalance;

        }

        /*
         *   This funciton allows us to decrement the balance of an account
         *   It perfomes a simple check to ensure the balance is greater than
         *   the amount being decremented.
         *   
         *   returns:
         *   true if the transactions if possible.
         *   false if there are insufficent funds in the account
         */
        public Boolean decrementBalance(int amount)
        {

            //  Lock which doesnt allow another Thread to access balance while another one is using it.
            lock (balanceLock)
            {

                if (this.balance >= amount)
                {

                    Random rnd = new Random();
                    int r = rnd.Next(1, 4);

                    /*
                    switch (r)
                    {
                        case 1:
                            Thread.Sleep(1000);
                            break;
                        case 2:
                            Thread.Sleep(5000);
                            break;
                        case 3:
                            Thread.Sleep(10000);
                            break;

                    }
                    */
                    balance -= amount;
                    return true;

                }
                else
                {

                    return false;

                }
            }
        }

        public Boolean incrementBalance(int amount)
        {

            balance += amount;
            return true;

        }

        /*
         * This funciton check the account pin against the argument passed to it
         *
         * Returns:
         * true if they match
         * false if they do not
         */
        public Boolean checkPin(int pinEntered)
        {

            if (pinEntered == pin)
            {

                return true;

            }
            else
            {

                return false;

            }
        }


        public int getAccountNum()
        {

            return accountNum;

        }

    }

    /* 
     *      This is out main ATM class that preforms the actions outlined in the assigment hand out
     *      
     *      the constutor contains the main funcitonality.
     */
    class ATM
    {
        //  Local referance to the array of accounts
        private Account[] ac;
        private bool exitStatus;
        int amount;

        // Account Number of the account number tahtsa being logged in
        private int accountNumber;

        //  This is a referance to the account that is being used
        private Account activeAccount = null;

        // Components of ATM UI
        private Form atmForm;
        private RichTextBox mainScreen;
        private TextBox inputBox;

        private PictureBox display;
        private PictureBox handMoney;
        private PictureBox cardSlot;
        private PictureBox displayB1;
        private PictureBox displayB2;
        private PictureBox displayB3;
        private PictureBox displayB4;
        private PictureBox displayB5;
        private PictureBox displayB6;
        private PictureBox displayB7;
        private PictureBox displayB8;

        private Button clearButton;
        private Button backButton;
        
        private Button enterAccountButton;
        private Button enterPinButton;

        private Button withdrawButton;
        private Button balanceButton;
        private Button exitAccountButton;
        private Button depositButton;

        private Button withdraw10Button;
        private Button withdraw50Button;
        private Button withdraw500Button;
        private Button withdrawAnyButton;
        private Button withdrawAnyEnterButton;

        private Button deposit10Button;
        private Button deposit50Button;
        private Button deposit500Button;
        private Button depositAnyButton;
        private Button depositAnyEnterButton;

        //load resources
        //load display and ATM images
        Bitmap backgroundImage = new Bitmap(Properties.Resources.ATM);
        Bitmap displayCard = new Bitmap(Properties.Resources.InsertCard);
        Bitmap displayCash = new Bitmap(Properties.Resources.TakeMoney);
        Bitmap displayPinType = new Bitmap(Properties.Resources.TypePIn);

        //gifs
        Bitmap takeCashGif = new Bitmap(Properties.Resources.CashOUT);
        Bitmap takeCardGif = new Bitmap(Properties.Resources.CardOUT);
        Bitmap putCardGif = new Bitmap(Properties.Resources.CardIN);

        //Text images
        Bitmap depositImg = new Bitmap(Properties.Resources.deposit);
        Bitmap deposit10Img = new Bitmap(Properties.Resources.deposit_10);
        Bitmap deposit50Img = new Bitmap(Properties.Resources.deposit_50);
        Bitmap deposit500Img = new Bitmap(Properties.Resources.deposit_5000);
        Bitmap depositAnyImg = new Bitmap(Properties.Resources.deposit_other_amount);
        Bitmap withdrawImg = new Bitmap(Properties.Resources.withdraw);
        Bitmap withdraw10Img = new Bitmap(Properties.Resources.withdraw_10);
        Bitmap withdraw50Img = new Bitmap(Properties.Resources.withdraw_50);
        Bitmap withdraw500Img = new Bitmap(Properties.Resources.withdraw_500);
        Bitmap withdrawAnyImg = new Bitmap(Properties.Resources.withdraw_other_amount);
        Bitmap displayBalanceImg = new Bitmap(Properties.Resources.display_balance);

        //load sounds
        SoundPlayer buttonSound = new SoundPlayer(Properties.Resources._402859__code419__spacebar);
        SoundPlayer cashOutSound = new SoundPlayer(Properties.Resources._41195__amabok__atm_withdrawal);
        SoundPlayer takeCard = new SoundPlayer(Properties.Resources._79022__engreitz__atm_ding);


        // The atm constructor takes an array of account objects as a referance
        public ATM(Account[] ac)
        {
            this.ac = ac;
            createForm();
            exitStatus = false;

        }



        public bool getExitStatus()
        {

            return exitStatus;

        }

        /*
         * Creates form for ATM
         * 
         */
        public void createForm()
        {
            //Creates form
            atmForm = new Form();
            atmForm.Size = new Size(615, 740);
            atmForm.BackgroundImage = backgroundImage;
            atmForm.FormBorderStyle = FormBorderStyle.FixedDialog;
            atmForm.MaximizeBox = false;

            /*
             * Creates display text for side buttons
             * 
             */
            displayB1 = new PictureBox();
            displayB1.SetBounds(99, 180, 100, 30);
            displayB1.Image = null;
            displayB1.BackColor = Color.Aquamarine;
            displayB1.Visible = false;


            displayB2 = new PictureBox();
            displayB2.SetBounds(99, 210, 100, 30);
            displayB2.Image = null;
            displayB2.BackColor = Color.Yellow;
            displayB2.Visible = false;

            displayB3 = new PictureBox();
            displayB3.SetBounds(99, 240, 100, 30);
            displayB3.Image = null;
            displayB3.BackColor = Color.Aquamarine;
            displayB3.Visible = false;

            displayB4 = new PictureBox();
            displayB4.SetBounds(285, 180, 100, 30);
            displayB4.Image = null;
            displayB4.BackColor = Color.Aquamarine;
            displayB4.Visible = false;

            displayB5 = new PictureBox();
            displayB5.SetBounds(285, 210, 100, 30);
            displayB5.Image = null;
            displayB5.BackColor = Color.Yellow;
            displayB5.Visible = false;

            displayB6 = new PictureBox();
            displayB6.SetBounds(285, 240, 100, 30);
            displayB6.Image = null;
            displayB6.BackColor = Color.Aquamarine;
            displayB6.Visible = false;

            displayB7 = new PictureBox();
            displayB7.SetBounds(285, 270, 100, 30);
            displayB7.Image = null;
            displayB7.BackColor = Color.Yellow;
            displayB7.Visible = false;

            displayB8 = new PictureBox();
            displayB8.SetBounds(99, 270, 100, 30);
            displayB8.Image = null;
            displayB8.BackColor = Color.Yellow;
            displayB8.Visible = false;

            /*
             * Picture boxes for gifs, not working due to threading issues
             */
            cardSlot = new PictureBox();
            cardSlot.SetBounds(100, 300, 400, 200);
            cardSlot.Image = putCardGif;

            handMoney = new PictureBox();
            handMoney.SetBounds(0, 300, 1000, 500);
            handMoney.BackColor = Color.Transparent;
            handMoney.Image = takeCashGif;

            //Main picture display
            display = new PictureBox();
            display.SetBounds(150, 75, 200, 250);
            display.BackColor = Color.Transparent;
            display.BackgroundImageLayout = ImageLayout.Stretch;
            display.Image = displayCard;


            createNumPad();

            //Main text display
            mainScreen = new RichTextBox();
            mainScreen.SetBounds(495, 130, 100, 100);
            mainScreen.Text += "Enter Account Number.";
            mainScreen.Enabled = false;

            //User Input display
            inputBox = new TextBox();
            inputBox.SetBounds(200, 287, 100, 50);
            inputBox.KeyPress += inputBox_KeyPress;
            inputBox.Enabled = false;

            /*
             * Various buttons setups
             */
            clearButton = new Button();
            clearButton.SetBounds(288, 460, 70, 40);
            clearButton.FlatStyle = FlatStyle.Flat;
            clearButton.BackColor = Color.Transparent;
            clearButton.FlatAppearance.BorderSize = 0;
            clearButton.TabStop = false;
            clearButton.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            clearButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            clearButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            clearButton.Click += clear_Click;

            enterAccountButton = new Button();
            enterAccountButton.Click += new EventHandler(this.enterAccount);
            enterAccountButton.SetBounds(288, 500, 80, 40);
            enterAccountButton.FlatStyle = FlatStyle.Flat;
            enterAccountButton.BackColor = Color.Transparent;
            enterAccountButton.FlatAppearance.BorderSize = 0;
            enterAccountButton.TabStop = false;
            enterAccountButton.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            enterAccountButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            enterAccountButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            enterAccountButton.Visible = true;

            enterPinButton = new Button();
            enterPinButton.Click += new EventHandler(this.enterPin);
            enterPinButton.SetBounds(288, 500, 80, 40);
            enterPinButton.FlatStyle = FlatStyle.Flat;
            enterPinButton.BackColor = Color.Transparent;
            enterPinButton.FlatAppearance.BorderSize = 0;
            enterPinButton.TabStop = false;
            enterPinButton.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            enterPinButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            enterPinButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            enterPinButton.Visible = false;

            withdrawButton = new Button();
            withdrawButton.Click += new EventHandler(this.withdrawCash);
            withdrawButton.SetBounds(37, 180, 60, 30);
            withdrawButton.FlatStyle = FlatStyle.Flat;
            withdrawButton.BackColor = Color.Transparent;
            withdrawButton.FlatAppearance.BorderSize = 0;
            withdrawButton.TabStop = false;
            withdrawButton.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            withdrawButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            withdrawButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            withdrawButton.Visible = false;

            withdraw10Button = new Button();
            withdraw10Button.Click += new EventHandler(this.withdraw10);
            withdraw10Button.SetBounds(37, 180, 60, 30);
            withdraw10Button.FlatStyle = FlatStyle.Flat;
            withdraw10Button.BackColor = Color.Transparent;
            withdraw10Button.FlatAppearance.BorderSize = 0;
            withdraw10Button.TabStop = false;
            withdraw10Button.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            withdraw10Button.FlatAppearance.MouseDownBackColor = Color.Transparent;
            withdraw10Button.FlatAppearance.MouseOverBackColor = Color.Transparent;
            withdraw10Button.Visible = false;


            withdraw50Button = new Button();
            withdraw50Button.Click += new EventHandler(this.withdraw50);
            withdraw50Button.SetBounds(37, 210, 60, 30);
            withdraw50Button.FlatStyle = FlatStyle.Flat;
            withdraw50Button.BackColor = Color.Transparent;
            withdraw50Button.FlatAppearance.BorderSize = 0;
            withdraw50Button.TabStop = false;
            withdraw50Button.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            withdraw50Button.FlatAppearance.MouseDownBackColor = Color.Transparent;
            withdraw50Button.FlatAppearance.MouseOverBackColor = Color.Transparent;
            withdraw50Button.Visible = false;

            withdraw500Button = new Button();
            withdraw500Button.Click += new EventHandler(this.withdraw500);
            withdraw500Button.SetBounds(37, 240, 60, 30);
            withdraw500Button.FlatStyle = FlatStyle.Flat;
            withdraw500Button.BackColor = Color.Transparent;
            withdraw500Button.FlatAppearance.BorderSize = 0;
            withdraw500Button.TabStop = false;
            withdraw500Button.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            withdraw500Button.FlatAppearance.MouseDownBackColor = Color.Transparent;
            withdraw500Button.FlatAppearance.MouseOverBackColor = Color.Transparent;
            withdraw500Button.Visible = false;

            withdrawAnyButton = new Button();
            withdrawAnyButton.Click += new EventHandler(this.withdrawAnyEnter);
            withdrawAnyButton.SetBounds(390, 180, 60, 30);
            withdrawAnyButton.FlatStyle = FlatStyle.Flat;
            withdrawAnyButton.BackColor = Color.Transparent;
            withdrawAnyButton.FlatAppearance.BorderSize = 0;
            withdrawAnyButton.TabStop = false;
            withdrawAnyButton.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            withdrawAnyButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            withdrawAnyButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            withdrawAnyButton.Visible = false;

            withdrawAnyEnterButton = new Button();
            withdrawAnyEnterButton.Click += new EventHandler(this.withdrawAny);
            withdrawAnyEnterButton.SetBounds(288, 500, 80, 40);
            withdrawAnyEnterButton.FlatStyle = FlatStyle.Flat;
            withdrawAnyEnterButton.BackColor = Color.Transparent;
            withdrawAnyEnterButton.FlatAppearance.BorderSize = 0;
            withdrawAnyEnterButton.TabStop = false;
            withdrawAnyEnterButton.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            withdrawAnyEnterButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            withdrawAnyEnterButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            withdrawAnyEnterButton.Visible = false;

            depositButton = new Button();
            depositButton.Click += new EventHandler(this.depositCash);
            depositButton.SetBounds(37, 240, 60, 30);
            depositButton.FlatStyle = FlatStyle.Flat;
            depositButton.BackColor = Color.Transparent;
            depositButton.FlatAppearance.BorderSize = 0;
            depositButton.TabStop = false;
            depositButton.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            depositButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            depositButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            depositButton.Visible = false;

            deposit10Button = new Button();
            deposit10Button.Click += new EventHandler(this.deposit10);
            deposit10Button.SetBounds(37, 180, 60, 30);
            deposit10Button.FlatStyle = FlatStyle.Flat;
            deposit10Button.BackColor = Color.Transparent;
            deposit10Button.FlatAppearance.BorderSize = 0;
            deposit10Button.TabStop = false;
            deposit10Button.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            deposit10Button.FlatAppearance.MouseDownBackColor = Color.Transparent;
            deposit10Button.FlatAppearance.MouseOverBackColor = Color.Transparent;
            deposit10Button.Visible = false;


            deposit50Button = new Button();
            deposit50Button.Click += new EventHandler(this.deposit50);
            deposit50Button.SetBounds(37, 210, 60, 30);
            deposit50Button.FlatStyle = FlatStyle.Flat;
            deposit50Button.BackColor = Color.Transparent;
            deposit50Button.FlatAppearance.BorderSize = 0;
            deposit50Button.TabStop = false;
            deposit50Button.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            deposit50Button.FlatAppearance.MouseDownBackColor = Color.Transparent;
            deposit50Button.FlatAppearance.MouseOverBackColor = Color.Transparent;
            deposit50Button.Visible = false;

            deposit500Button = new Button();
            deposit500Button.Click += new EventHandler(this.deposit500);
            deposit500Button.SetBounds(37, 240, 60, 30);
            deposit500Button.FlatStyle = FlatStyle.Flat;
            deposit500Button.BackColor = Color.Transparent;
            deposit500Button.FlatAppearance.BorderSize = 0;
            deposit500Button.TabStop = false;
            deposit500Button.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            deposit500Button.FlatAppearance.MouseDownBackColor = Color.Transparent;
            deposit500Button.FlatAppearance.MouseOverBackColor = Color.Transparent;
            deposit500Button.Visible = false;

            depositAnyButton = new Button();
            depositAnyButton.Click += new EventHandler(this.depositAnyEnter);
            depositAnyButton.SetBounds(390, 180, 60, 30);
            depositAnyButton.FlatStyle = FlatStyle.Flat;
            depositAnyButton.BackColor = Color.Transparent;
            depositAnyButton.FlatAppearance.BorderSize = 0;
            depositAnyButton.TabStop = false;
            depositAnyButton.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            depositAnyButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            depositAnyButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            depositAnyButton.Visible = false;

            depositAnyEnterButton = new Button();
            depositAnyEnterButton.Click += new EventHandler(this.depositAny);
            depositAnyEnterButton.SetBounds(288, 500, 80, 40);
            depositAnyEnterButton.FlatStyle = FlatStyle.Flat;
            depositAnyEnterButton.BackColor = Color.Transparent;
            depositAnyEnterButton.FlatAppearance.BorderSize = 0;
            depositAnyEnterButton.TabStop = false;
            depositAnyEnterButton.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            depositAnyEnterButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            depositAnyEnterButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            depositAnyEnterButton.Visible = false;

            balanceButton = new Button();
            balanceButton.Click += new EventHandler(this.displayBalance);
            balanceButton.SetBounds(37, 210, 60, 30);
            balanceButton.FlatStyle = FlatStyle.Flat;
            balanceButton.BackColor = Color.Transparent;
            balanceButton.FlatAppearance.BorderSize = 0;
            balanceButton.TabStop = false;
            balanceButton.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            balanceButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            balanceButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            balanceButton.Visible = false;

            backButton = new Button();
            backButton.Click += new EventHandler(this.back);
            backButton.SetBounds(285, 420, 70, 40);
            backButton.FlatStyle = FlatStyle.Flat;
            backButton.BackColor = Color.Transparent;
            backButton.FlatAppearance.BorderSize = 0;
            backButton.TabStop = false;
            backButton.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            backButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            backButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            backButton.Visible = false;

            exitAccountButton = new Button();
            exitAccountButton.Click += new EventHandler(this.exitAccount);
            exitAccountButton.SetBounds(285, 420, 70, 40);
            exitAccountButton.FlatStyle = FlatStyle.Flat;
            exitAccountButton.BackColor = Color.Transparent;
            exitAccountButton.FlatAppearance.BorderSize = 0;
            exitAccountButton.TabStop = false;
            exitAccountButton.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            exitAccountButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            exitAccountButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            exitAccountButton.Visible = false;

            //Adds everything to the form
            atmForm.Controls.Add(mainScreen);
            atmForm.Controls.Add(inputBox);
            atmForm.Controls.Add(clearButton);
            atmForm.Controls.Add(enterAccountButton);
            atmForm.Controls.Add(enterPinButton);
            atmForm.Controls.Add(withdrawButton);
            atmForm.Controls.Add(balanceButton);
            atmForm.Controls.Add(exitAccountButton);
            atmForm.Controls.Add(withdraw10Button);
            atmForm.Controls.Add(withdraw50Button);
            atmForm.Controls.Add(withdraw500Button);
            atmForm.Controls.Add(withdrawAnyButton);
            atmForm.Controls.Add(withdrawAnyEnterButton);
            atmForm.Controls.Add(depositButton);
            atmForm.Controls.Add(deposit10Button);
            atmForm.Controls.Add(deposit50Button);
            atmForm.Controls.Add(deposit500Button);
            atmForm.Controls.Add(depositAnyButton);
            atmForm.Controls.Add(depositAnyEnterButton);
            atmForm.Controls.Add(backButton);
            atmForm.Controls.Add(display);
            atmForm.Controls.Add(displayB1);
            atmForm.Controls.Add(displayB2);
            atmForm.Controls.Add(displayB3);
            atmForm.Controls.Add(displayB4);
            atmForm.Controls.Add(displayB5);
            atmForm.Controls.Add(displayB6);
            atmForm.Controls.Add(displayB7);
            atmForm.Controls.Add(displayB8);
            // atmForm.Controls.Add(handMoney); Not working from thread issues
            // atmForm.Controls.Add(cardSlot); Not working from thread issues
            atmForm.ShowDialog();

        }

        //Creates numpad buttons in an array
        public void createNumPad()
        {

            Button[] numPad = new Button[10];
            int temp = 1;
            int width = 55;
            int height = 40;

            for (int i = 0; i < 10; i++)
            {
                //setups button appearance
                numPad[i] = new Button();
                numPad[i].FlatStyle = FlatStyle.Flat;
                numPad[i].BackColor = Color.Transparent;
                numPad[i].FlatAppearance.BorderSize = 0;
                numPad[i].TabStop = false;
                numPad[i].FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
                numPad[i].FlatAppearance.MouseDownBackColor = Color.Transparent;
                numPad[i].FlatAppearance.MouseOverBackColor = Color.Transparent;

                if (temp == 4)
                {

                    temp = 1;

                }

                if (i == 0)
                {
                    numPad[i].SetBounds(width * 2 + 52, 540, width, height);
                    temp--;


                }
                else if (i < 4)
                {

                    numPad[i].SetBounds((width-4) * temp + 70, 420, width - 4, height);

                }
                else if (i < 7)
                {

                    numPad[i].SetBounds((width - 2) * temp + 62, 460, width - 2, height);

                }
                else
                {
                    numPad[i].SetBounds(width * temp + 56, 500, width, height);

                }

                numPad[i].Text = i.ToString();
                numPad[i].Click += new EventHandler(ButtonClick);
                atmForm.Controls.Add(numPad[i]);

                temp++;
            }

        }

        //button clicks go to inuput box
        private void ButtonClick(object sender, EventArgs e)
        {
            buttonSound.Play();
            Button btn = sender as Button;
            inputBox.Text += btn.Text;

        }

        //clears inputbox
        private void clear_Click(object sender, EventArgs e)
        {
            buttonSound.Play();
            inputBox.Text = " ";

        }

        private void inputBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }

            /*
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
            */
        }

        private void back(object sender, EventArgs e)
        {
            buttonSound.Play();
            dispOptions();
        }

        
        /*
         * Stores Account Number in inputbox and asks for Pin
         * 
        */
        private void enterAccount(object sender, EventArgs e)
        {
            buttonSound.Play();

            if (inputBox.Text == "")
            {
                mainScreen.Text = "Can't Find Account, Try Again";
            }
            else
            {
                // Gets accountNumber in input box
                accountNumber = Int32.Parse(inputBox.Text);
                enterAccountButton.Visible = false;
                inputBox.Text = "";
                display.Image = displayPinType;
                

                // Asks for pin input
                mainScreen.Text = "Please Enter Pin.";
                enterPinButton.Visible = true;
            }
        }

        /*
         * Stores pin thats in inputbox and calls function to check if the details match
         * 
        */
        private void enterPin(object sender, EventArgs e)
        {
            buttonSound.Play();


            // Gets inputs in input box


            if (inputBox.Text == "")
                {
                    mainScreen.Text = "Incorrect Pin, Try Again";
                }
                else
                {
                    int pin = Int32.Parse(inputBox.Text);
                    inputBox.Text = "";
                    checkEnterDetails(pin);
                }

            
        }

        /*
         * Checks if Entered Details match an accounts details
         * 
        */
        public void checkEnterDetails(int pin)
        {

            // If account exits
            if (this.findAccount(accountNumber) == true)
            {

                // If correct pin, enter account
                if (checkPin(pin) == true)
                {
                    display.Image = null;
                    display.Visible = false;

                    // Display welcome message
                    mainScreen.Text = "Welcome <" + activeAccount.getAccountNum() + ">";

                    // Display account options
                    dispOptions();

                }
                else
                {
                    // Display Error Message
                    mainScreen.Text = "Incorrect Pin\n";
                    mainScreen.Text += "Enter Account Number";
                    display.Image = displayCard;
                    enterAccountButton.Visible = true;
                    enterPinButton.Visible = false;

                }


            }
            else
            {

                // Display Error Message
                mainScreen.Text = "Account Number does not match any existing Accounts\n";
                mainScreen.Text += "Enter Account Number.";
                display.Image = displayCard;
                enterAccountButton.Visible = true;
                enterPinButton.Visible = false;


            }

        }

        /*
         * Searches for account number
         * 
         */
        private bool findAccount(int account)
        {   
         
            for (int i = 0; i < this.ac.Length; i++)
            {

                // If account is in accounts
                if (ac[i].getAccountNum() == account)
                {

                    activeAccount = ac[i];
                    return true;

                }
                
            }

            return false;

        }


        /*
         * Checks if parameter pin matches currently activeAccount pin
         * 
         */
        private bool checkPin(int pin)
        {

            // Check if pin is correct
            if (activeAccount.checkPin(pin))
            {
                // If the pin is a match give the options to do stuff to the account (take money out, view balance, exit)
                return true;

            }
            else
            {

                return false;

            }
        }


        

        /*
         *  Display account options
         *  
         */
        private void dispOptions()
        {

            mainScreen.Text += "\n1: Withdraw\n";
            mainScreen.Text += "2: View Balance\n";
            mainScreen.Text += "3: Deposit\n";

            displayB1.Image = withdrawImg;
            displayB2.Image = displayBalanceImg;
            displayB3.Image = depositImg;
            displayB4.Image = null;
            displayB1.Visible = true;
            displayB2.Visible = true;
            displayB3.Visible = true;
            displayB4.Visible = true;
            displayB5.Visible = true;
            displayB6.Visible = true;
            displayB7.Visible = true;
            displayB8.Visible = true;

            withdraw10Button.Visible = false;
            withdraw50Button.Visible = false;
            withdraw500Button.Visible = false;
            withdrawAnyButton.Visible = false;
            withdrawAnyEnterButton.Visible = false;
            enterPinButton.Visible = false;
            withdrawButton.Visible = true;
            balanceButton.Visible = true;
            exitAccountButton.Visible = true;
            deposit10Button.Visible = false;
            deposit50Button.Visible = false;
            deposit500Button.Visible = false;
            depositButton.Visible = true;
            depositAnyButton.Visible = false;
            depositAnyEnterButton.Visible = false;
            inputBox.Visible = false;
            backButton.Visible = false;




        }

        /*
         * Changes ATM UI to display withdraw options
         *
         */
        private void withdrawCash(object sender, EventArgs e)
        {
            buttonSound.Play();


            mainScreen.Text = "Withdraw";

            withdraw10Button.Visible = true;
            displayB1.Image = withdraw10Img;

            withdraw50Button.Visible = true;
            displayB2.Image = withdraw50Img;

            withdraw500Button.Visible = true;
            displayB3.Image = withdraw500Img;

            withdrawAnyButton.Visible = true;
            displayB4.Image = withdrawAnyImg;

            inputBox.Visible = false;

            withdrawAnyEnterButton.Visible = false;
            withdrawButton.Visible = false;
            balanceButton.Visible = false;
            exitAccountButton.Visible = false;
            depositButton.Visible = false;
            backButton.Visible = true;



        }


        // Withdraw £10 money
        private void withdraw10(object sender, EventArgs e)
        {
            buttonSound.Play();


            //attempt to decrement account by £10
            if (activeAccount.decrementBalance(10))
            {
                cashOutSound.Play();

                //if this is possible display new balance and await key press
                mainScreen.Text = "new balance " + activeAccount.getBalance();
 
            }
            else
            {
                mainScreen.Text = "insufficent funds";
                
            }

            dispOptions();

        }

        // Withdraw 50 money
        private void withdraw50(object sender, EventArgs e)
        {
            buttonSound.Play();

            if (activeAccount.decrementBalance(50))
            {
                cashOutSound.Play();
                mainScreen.Text = "new balance " + activeAccount.getBalance();

            }
            else
            {
                mainScreen.Text = "insufficent funds";
               
            }

            dispOptions();

        }

        // Withdraw 500 money
        private void withdraw500(object sender, EventArgs e)
        {
            buttonSound.Play();

            if (activeAccount.decrementBalance(500))
            {
                cashOutSound.Play();
                mainScreen.Text = "new balance " + activeAccount.getBalance();

            }
            else
            {

                mainScreen.Text = "Insufficent funds";


            }

            dispOptions();

        }

        // Withdraw user input amount menu
        private void withdrawAnyEnter(object sender, EventArgs e)
        {
            buttonSound.Play();
            
            mainScreen.Text = "Enter Amount to Withdraw";

            inputBox.Visible = true;

            displayB1.Image = null;
            displayB2.Image = null;
            displayB3.Image = null;
            displayB4.Image = null;
            displayB1.Visible = false;
            displayB2.Visible = false;
            displayB3.Visible = false;
            displayB4.Visible = false;
            displayB5.Visible = false;
            displayB6.Visible = false;
            displayB7.Visible = false;
            displayB8.Visible = false;

            withdraw10Button.Visible = false;
            withdraw50Button.Visible = false;
            withdraw500Button.Visible = false;
            withdrawAnyEnterButton.Visible = true;
            withdrawAnyButton.Visible = false;
            
            
        }

        // Withdraw user input amount 
        private void withdrawAny(object sender, EventArgs e)
        {
            buttonSound.Play();


            if (inputBox.Text == "")
            {
                mainScreen.Text = "Please enter valid amount";
            }
            else
            {
                amount = Int32.Parse(inputBox.Text);
                inputBox.Text = "";

                if (activeAccount.decrementBalance(amount))
                {
                    cashOutSound.Play();
                    mainScreen.Text = "new balance " + activeAccount.getBalance();

                }
                else
                {

                    mainScreen.Text = "Insufficent funds";


                }

                dispOptions();
                amount = 0;
            }
        
        }

        /*
         * Changes ATM UI to display deposit options
         *
        */
        private void depositCash(object sender, EventArgs e)
        {
            buttonSound.Play();


            mainScreen.Text = "Deposit";

            inputBox.Visible = false;

            displayB1.Image = deposit10Img;
            displayB2.Image = deposit50Img;
            displayB3.Image = deposit500Img;
            displayB4.Image = depositAnyImg;

            deposit10Button.Visible = true;
            deposit50Button.Visible = true;
            deposit500Button.Visible = true;
            depositAnyButton.Visible = true;

            depositButton.Visible = false;
            balanceButton.Visible = false;
            exitAccountButton.Visible = false;
            withdrawButton.Visible = false;
            backButton.Visible = true;


        }


        // deposit £10 money
        private void deposit10(object sender, EventArgs e)
        {
            buttonSound.Play();

            //attempt to decrement account by £10
            if (activeAccount.incrementBalance(10))
            {
                //if this is possible display new balance and await key press
                mainScreen.Text = "New balance " + activeAccount.getBalance();

            }
            else
            {
                mainScreen.Text = "Error adding funds, please try again";

            }

            dispOptions();

        }

        // deposit 50 money
        private void deposit50(object sender, EventArgs e)
        {
            buttonSound.Play();

            if (activeAccount.incrementBalance(50))
            {

                mainScreen.Text = "New balance " + activeAccount.getBalance();

            }
            else
            {
                mainScreen.Text = "Error adding funds, please try again";

            }

            dispOptions();

        }

        // deposit 500 money
        private void deposit500(object sender, EventArgs e)
        {
            buttonSound.Play();

            if (activeAccount.incrementBalance(500))
            {

                mainScreen.Text = "New balance " + activeAccount.getBalance();

            }
            else
            {

                mainScreen.Text = "Error adding funds, please try again";


            }

            dispOptions();

        }

        // deposit user input amount
        private void depositAnyEnter(object sender, EventArgs e)
        {
            buttonSound.Play();

            mainScreen.Text = "Enter Amount to Deposit";

            displayB1.Image = null;
            displayB2.Image = null;
            displayB3.Image = null;
            displayB4.Image = null;
            displayB1.Visible = false;
            displayB2.Visible = false;
            displayB3.Visible = false;
            displayB4.Visible = false;
            displayB5.Visible = false;
            displayB6.Visible = false;
            displayB7.Visible = false;
            displayB8.Visible = false;

            inputBox.Visible = true;
            deposit10Button.Visible = false;
            deposit50Button.Visible = false;
            deposit500Button.Visible = false;
            depositAnyEnterButton.Visible = true;
            depositAnyButton.Visible = false;


        }

        //Custom user input deposit
        private void depositAny(object sender, EventArgs e)
        {
            buttonSound.Play();

            if (inputBox.Text == "")
            {
                mainScreen.Text = "Please enter valid amount";
            }
            else
            {
                amount = Int32.Parse(inputBox.Text);
                inputBox.Text = "";

                if (activeAccount.incrementBalance(amount))
                {

                    mainScreen.Text = "New balance " + activeAccount.getBalance();

                }
                else
                {

                    mainScreen.Text = "Error adding funds, please try again";


                }

                amount = 0;
                dispOptions();
            }

        }

        /*
        *  display balance of activeAccount
        *  
        */
        private void displayBalance(object sender, EventArgs e)
        {
            buttonSound.Play();

            mainScreen.Text = " " + activeAccount.getBalance();
            dispOptions();

        }

        /*
         * Exits currently active Account
         */
        private void exitAccount(object sender, EventArgs e)
        {
            buttonSound.Play();

            mainScreen.Text = "Please Enter Account Number";
            activeAccount = null;
            enterAccountButton.Visible = true;
            enterPinButton.Visible = false;
            withdrawButton.Visible = false;
            balanceButton.Visible = false;
            displayB1.Image = null;
            displayB2.Image = null;
            displayB3.Image = null;
            displayB4.Image = null;
            displayB1.Visible = false;
            displayB2.Visible = false;
            displayB3.Visible = false;
            displayB4.Visible = false;
            displayB5.Visible = false;
            displayB6.Visible = false;
            displayB7.Visible = false;
            displayB8.Visible = false;
            exitAccountButton.Visible = false;
            withdraw10Button.Visible = false;
            withdraw50Button.Visible = false;
            withdraw500Button.Visible = false;
            withdrawAnyButton.Visible = false;
            depositButton.Visible = false;
            deposit10Button.Visible = false;
            deposit50Button.Visible = false;
            deposit500Button.Visible = false;
            depositAnyButton.Visible = false;
            backButton.Visible = false;
            inputBox.Text = " ";
            inputBox.Visible = true;
            display.Visible = true;

        }

        private void exitATM(object sender, EventArgs e)
        {

                exitStatus = true;

        }
    }

}